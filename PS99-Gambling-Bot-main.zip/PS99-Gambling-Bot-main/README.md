https://discord.gg/eUK8ykMXQK support server, join for help
credits: henrymistert
## This is the free version!  
contact me on discord (blinxoo) for a showcase of the premium version or if you want to put an offer in! It is much more clean, user friendly and has more features.

you can see screenshots of the premium version (soon)

## Games

💣 - **Mines:** The user picks a bet and a certain amount of bombs and has to press buttons in a 5x5 grid to uncover tiles to either increase their multiplier if its safe, or lose their multiplier if its a bomb  
🪜 - **Towers:** Pick a bet and climb up a tower, choose either middle left or right, one will make you fall and the others will make you climb higher and increase your multiplier  
💎 - **Keno:** Choose 6 tiles on a 5x5 grid and 6 tiles will be randomly selected, depending on how many randomly chosen tiles land on your tiles you will get a higher multiplier  
🚀 - **Crash:** A live game where every minute a rocket launches and people bet on how high it will fly before it crashes  
🪙 - **Coinflip:** Pick a bet and heads or tails and a coinflip will be created a channel, anyone can join this coinflip or you can call the bot to play with you  
💼 - **Cases:** Open cases to either get a pet worth less than what you paid for the case or more  
🍀 - **Upgrader:** Multiply your gems  
🎲 - **Dice:** Roll a dice against the bot and get 3x your bet if you win  

## Features

🔥 **Affiliates:** When affiliating someone you get 250m Balance and your affiliate gets a percentage of your bets without taking anything from you  
💎 **Rake Back:** Get a percentage of your losses back  
💖 **Tipping:** Give someone free gems  
🌧️ **Rains:** Rain your gems and they get split between everyone that joins the rain
